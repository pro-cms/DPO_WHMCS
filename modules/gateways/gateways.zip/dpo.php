<?php
/*
 * Copyright (c) 2021 selcom Group
 *
 * Author: App Inlet (Pty) Ltd
 *
 * Released under the GNU General Public License
 *
 * This module facilitates selcom Group payments for WHMCS clients
 *
 */

// Require libraries needed for gateway module functions
require_once __DIR__ . '/../../init.php';
require_once __DIR__ . '/../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../includes/invoicefunctions.php';

require_once 'selcom/lib/constants.php';
require_once 'selcom/lib/selcom.php';

if ( !defined( "WHMCS" ) ) {
    die( "This file cannot be accessed directly" );
}

use WHMCS\Database\Capsule;

if ( !defined( '_DB_PREFIX_' ) ) {
    define( '_DB_PREFIX_', 'tbl' );
}

/**
 * Check for existence of SelcomPayselcom table and create if not
 * In earlier versions this table was named paygateselcom -> rename if necessary
 */
 

 

if ( isset( $_POST['INITIATE'] ) && $_POST['INITIATE'] == 'initiate' ) {
    $params    = json_decode( base64_decode( $_POST['jparams'] ), true );
    $systemUrl = $params['systemurl'];

    selcom_initiate( $params );
}

/**
 * Define module related meta data
 *
 * Values returned here are used to determine module related capabilities and
 * settings
 *
 * @return array
 */
function selcom_MetaData()
{
    return array(
        'DisplayName'                 => 'Direct Pay Online (selcom)',
        'APIVersion'                  => '1.1', // Use API Version 1.1
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage'            => true,
    );
}

/**
 * Define gateway configuration options
 *
 *
 * @return array
 */
function selcom_config()
{
    return array(
        // defined here for backwards compatibility
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => ' selcom Payment Gateway',
        ),
        // a text field type allows for single line text input
        'vendorID' => array(
            'FriendlyName' => 'Vendor ID',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your app Name here',
        ),
        // a text field type allows for single line text input
        'apiKey' => array(
            'FriendlyName' => 'API key',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Client ID here',
        ),
         // a text field type allows for single line text input
         'apiSecret' => array(
            'FriendlyName' => 'API secret',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Client ID here',
        ),
        // the yesno field type displays a single checkbox option
        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),

         // a text field type allows for single line text input
         'redirect_url' => array(
            'FriendlyName' => 'Redirect URL',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Client ID here',
        ),
         // a text field type allows for single line text input
         'cancel_url' => array(
            'FriendlyName' => 'Cancel URL',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your Client ID here',
        ),
        // the yesno field type displays a single checkbox option
        'webhook' => array(
            'FriendlyName' => 'Cancel URL',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),
    );
}

function selcom_link( $params )
{
    $jparams   = base64_encode( json_encode( $params ) );
    $systemurl = $params['systemurl'];
    $html      = <<<HTML
    <form method="post" action="{$systemurl}modules/gateways/selcom.php" >
    <input type="hidden" name="INITIATE" value="initiate" />
    <input type="hidden" name="jparams" value="$jparams" />
    <input type="submit" value="Pay Using Selcom" />
    </form>
HTML;

    return $html;
}

function selcom_initiate( $params )
{
    $testMode = false;
    // Callback urls
    $systemUrl = $params['systemurl'];
    $notifyUrl = $systemUrl . 'modules/gateways/callback/selcom.php';
    $returnUrl = $systemUrl . 'modules/gateways/callback/selcom.php';

    $vendor = $params['vendorID'];
    $apiKey = $params['apiKey'];
    $apiSecret = $params['apiSecret'];
    $redirect_url = base64_encode($params['redirect_url']);
    $cancel_url = base64_encode($params['cancel_url']);
    $webhook = base64_encode($params['webhook']);
    $invoiceId = $params['invoiceid'];
    $amount = $params['amount'];
    $phone =  $params['clientdetails']['phonenumber'];
    $email = $params['clientdetails']['email'];
    $fullName = $params['clientdetails']['firstname']. " ".$params['clientdetails']['lastname'];

    $data =[
        "vendor" =>  $vendor,
        "order_id" => $invoiceId,
        "buyer_email" => $email,
        "buyer_name" => $fullName,
        "buyer_phone" => "255977777777",
        "amount" => $amount,
        "currency" =>  $params['currency'],
        "payment_methods" => "ALL",
        "redirect_url" => $redirect_url,
        "cancel_url" =>  $cancel_url,
        "webhook" => $webhook,
        "billing" => [
          "firstname" =>  $params['clientdetails']['firstname'],
          "lastname" =>$params['clientdetails']['lastname'],
          "address_1" => $params['clientdetails']['address1'],
          "address_2" => $params['clientdetails']['address2'],
          "city" => $params['clientdetails']['city'],
          "state_or_region" => $params['clientdetails']['region']??"Dar Es Salaam",
          "postcode_or_pobox" => $params['clientdetails']['zipcode'],
          "country" => "TZ",
          "phone" =>   $phone
        ],
        "no_of_items" => 1
    ];

    // Create token
    $selcom    = new SelcomPay\selcom($apiKey,$apiSecret,$vendor);
    $payment_link = $selcom->createPaymentLink($data);

    if ( $payment_link!=null) {
        header( 'Location: ' . $payment_link );


    } else {
        echo 'Something went wrong: ' ;
        $url = $systemUrl . 'viewinvoice.php?id=' . $data['companyRef'];
        echo <<<HTML
<br><br><a href="$url">Click here to return</a>
HTML;

    }
}
